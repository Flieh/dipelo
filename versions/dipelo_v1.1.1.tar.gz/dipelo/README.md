# ddelo
Elo style ratings for droidippy players
