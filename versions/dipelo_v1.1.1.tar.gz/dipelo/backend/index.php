<!doctype html> 
<html> 
<head> 

	<meta charset="utf-8" />
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />

	<title>DDELO</title> 
	
	<?php 
		require "php/ddelofunc.php" ;
		require "kint/Kint.class.php";
	?>

</head>
 
<body> 
	
	<?php	
		require "menu.html";
	?>
	
</body> 
</html>