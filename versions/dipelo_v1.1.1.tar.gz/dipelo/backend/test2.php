<?php

	require "php/ddelofunc.php" ;
	require "kint/Kint.class.php";

	echo strtotime("2016-2-1") - strtotime("2016-1-1") "<br>";

	
?>